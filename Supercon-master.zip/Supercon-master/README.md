# Supercon
Data used in "Machine learning modeling of superconducting critical temperature" paper.
Downloaded from SuperCon database. The first column ("name") gives the chemical composition of the compound in format element - weight (number). The second column gives the critical temperatue of the compound. Materials without reported critical temperatue have been assigned Tc=0.    
